<footer class='container footer-section row'>
    <div class='col-lg-6 col-md-12 text-sm-center text-md-center tex-lg-start text-center'>
        <p>Copyright © 2023 Karka Acadamy</p>
    </div>
    <div class="col-lg-6 col-md-12 text-sm-center text-md-center text-lg-end text-center">
        <a href="index.php" target="_self" class="text-decoration-none">Home</a>            
        <a href="about_us.php" target="_self" class="text-decoration-none">About</a>            
        <a href="fullstack.php" target="_self" class="text-decoration-none">Blog</a>            
        <a href="fees_pap.php" target="_self" class="text-decoration-none">Service</a>            
        <button type='button' class='get-in' onclick="window.location.href='https://docs.google.com/forms/d/e/1FAIpQLSe4phCAjzTkmmmrnTVQCGNw7ciet2pvrSROqz3a6QufHbBrKA/viewform'">GET TOUCH</button>        
    </div>
</footer>